# SQLAlchemy
from sqlalchemy.ext.declarative import declarative_base

"""Define the base for models"""
Base = declarative_base()