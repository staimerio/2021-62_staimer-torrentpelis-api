TYPES = {
    u'movies': 1,
    u'shows': 2,
}